package com.softuni.battleshipss.models;

public enum ShipType {
    BATTLE, CARGO, PATROL
}
