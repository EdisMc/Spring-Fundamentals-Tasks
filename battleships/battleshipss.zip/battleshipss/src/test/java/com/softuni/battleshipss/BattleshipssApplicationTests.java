package com.softuni.battleshipss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BattleshipssApplicationTests {

	@Test
	void contextLoads() {
	}

}
