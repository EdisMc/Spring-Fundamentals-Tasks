package com.softuni.battleshipss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BattleshipssApplication {

	public static void main(String[] args) {
		SpringApplication.run(BattleshipssApplication.class, args);
	}

}
